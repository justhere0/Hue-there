# Hue & There

Open `index.html` in a modern browser. Keep `index.html`, `styles.css`, `data.js`, `app.js`, and `smoke-checks.js` together in the same folder.

For lightweight browser checks, open `index.html?smoke=1` and inspect the browser console. The checks cover startup, accessible announcements, shop catalogs, settings persistence/defaults, and timer reset behavior.
