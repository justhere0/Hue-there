// Open index.html?smoke=1 to run these lightweight browser checks.
(async function runHueThereSmokeChecks() {
  if (!new URLSearchParams(location.search).has('smoke')) return;

  const results = [];
  const assert = (condition, message) => {
    if (!condition) throw new Error(message);
    results.push(`PASS ${message}`);
  };
  const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

  try {
    assert(Boolean(window.hueThereState), 'app initializes and exposes its state');
    assert(document.querySelectorAll('#board .tube').length > 0, 'Tube Sort renders a board');
    assert(document.querySelector('#instruction').getAttribute('aria-live') === 'polite', 'game instructions announce updates');

    document.querySelector('#shopOpen').click();
    const shop = document.querySelector('#shopDialog');
    assert(shop.open, 'shop dialog opens');
    assert(document.querySelectorAll('#shopMusic .theme-card').length === 8, 'all eight soundtracks appear in the shop');
    assert(document.querySelectorAll('#shopThemes .theme-card').length >= 12, 'new color palettes appear in the shop');
    shop.close();

    document.querySelector('#openSettings').click();
    const settings = document.querySelector('#settingsDialog');
    assert(settings.open, 'settings dialog opens');
    assert(document.querySelector('#musicVolume').value === '35', 'music slider starts at its default');
    assert(document.querySelector('#soundVolume').value === '55', 'sound slider starts at its default');
    assert(document.querySelector('#masterVolume').value === '65', 'master slider starts at its default');
    const musicVolume = document.querySelector('#musicVolume');
    musicVolume.value = '42';
    musicVolume.dispatchEvent(new Event('input', { bubbles: true }));
    const progress = JSON.parse(localStorage.getItem('hue-there-progress') || '{}');
    assert(progress.musicVolume === 42, 'settings changes save to local storage');
    document.querySelector('#resetSettings').click();
    settings.close();

    const progressAfterReset = JSON.parse(localStorage.getItem('hue-there-progress') || '{}');
    assert(progressAfterReset.coinBalance === 0, 'new profile has zero coins');
    assert(JSON.stringify(progressAfterReset.ownedThemeIds) === JSON.stringify(['classic']), 'new profile owns only the default palette');
    assert(JSON.stringify(progressAfterReset.ownedMusicTrackIds) === JSON.stringify(['calm-current']), 'new profile owns only the free soundtrack');

    document.querySelector('#startGame').click();
    let tubes = window.hueThereState.tubes;
    let move = null;
    for (let from = 0; from < tubes.length && !move; from++) {
      if (!tubes[from].length || tubes[from].length === 4 && tubes[from].every(color => color === tubes[from][0])) continue;
      const to = tubes.findIndex((tube, index) => index !== from && tube.length === 0);
      if (to >= 0) move = [from, to];
    }
    assert(Boolean(move), 'a legal Tube Sort move exists for timer smoke test');
    let tubeButtons = document.querySelectorAll('#board .tube');
    tubeButtons[move[0]].click();
    tubeButtons[move[1]].click();
    await pause(1100);
    assert(document.querySelector('#timer').textContent !== '0:00', 'game timer starts after a valid move');
    document.querySelector('#restart').click();
    assert(document.querySelector('#timer').textContent === '0:00', 'restarting resets the game timer');

    window.hueThereSmokeResults = results;
    console.info('Hue & There smoke checks passed:', results);
  } catch (error) {
    window.hueThereSmokeResults = [...results, `FAIL ${error.message}`];
    console.error('Hue & There smoke check failed:', error);
  }
})();
