"""Static smoke checks for the standalone Hue & There project."""
from html.parser import HTMLParser
from pathlib import Path
import re

ROOT = Path(__file__).parent

class Assets(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs = []
        self.inline_style = False
        self.inline_script = False
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "link" and attrs.get("rel") == "stylesheet":
            self.refs.append(attrs.get("href"))
        if tag == "script" and attrs.get("src"):
            self.refs.append(attrs["src"])
        if tag == "style": self.inline_style = True
        if tag == "script" and not attrs.get("src"): self.inline_script = True

html = (ROOT / "index.html").read_text()
css = (ROOT / "styles.css").read_text()
app = (ROOT / "app.js").read_text()
data = (ROOT / "data.js").read_text()
checks = Assets()
checks.feed(html)
assert checks.refs == ["styles.css", "data.js", "app.js", "smoke-checks.js"], checks.refs
assert not checks.inline_style and not checks.inline_script
assert all((ROOT / ref).is_file() for ref in checks.refs)
assert len(re.findall(r"\bid:'", re.search(r"const colorThemes=\[(.*?)\];\nconst nightmareThemes", data, re.S).group(1))) == 12
assert len(re.findall(r"\bid:'", re.search(r"const musicTracks=\[(.*?)\];\nconst winMessages", data, re.S).group(1))) == 8
assert "window.HueThereData={spectrumColors,colorThemes,nightmareThemes,musicTracks,winMessages,difficultyMessages}" in data
assert "window.hueThereState=state" in app and "const elementCache=new Map()" in app
assert "resetForFreshProfile();try" in app and "safeParseJSON" in app and "safeLocalStorageSet" in app
assert "outputVolume=channel==='music'?volume*1.6:volume" in app
assert "focus-visible" in css and "prefers-reduced-motion:reduce" in css
for ident in ("instruction", "spectrumStatus", "basketStatus", "memoryStatus", "connectStatus", "sequenceStatus"):
    assert re.search(rf'id="{ident}"[^>]*aria-live="polite"', html)
for ident, value in (("musicVolume", "35"), ("soundVolume", "55"), ("masterVolume", "65")):
    assert re.search(rf'id="{ident}"[^>]*value="{value}"', html)
assert "index.html?smoke=1" in (ROOT / "README.md").read_text()
print("PASS: split assets load in order; 12 palettes and 8 soundtracks are present")
print("PASS: state/storage helpers, clean defaults, focus styles, reduced motion, and live regions are present")
print("PASS: browser smoke runner is included")
